package Enums;

public enum NotificationAddressee {
    SENDER,
    RECIPIENT
}
