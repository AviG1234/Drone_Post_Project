import Services.ServerManager;

public class Main {

    public static void main (String [] args) {
        ServerManager.startServer();
    }
}
