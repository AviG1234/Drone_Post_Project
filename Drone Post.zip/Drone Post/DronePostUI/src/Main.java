import Services.ClientManager;

public class Main {


    public static void main (String [] args) {
        ClientManager.startClient();

    }
}
